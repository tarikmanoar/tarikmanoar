<h3 align="center">Hi, Manoar <img src="https://raw.githubusercontent.com/nixin72/nixin72/master/wave.gif" 
         alt="Waving hand animated gif" height="45" width="45" /></h3>

<br>

<p align="center">
 <a target="_blank" href=https://github.com/tarikmanoar>
  <img src=https://img.shields.io/github/followers/tarikmanoar?label=follow%20me&style=social />
  &nbsp;
</a>

<a target="_blank" href=https://codeforces.com/profile/blue_edge>
  <img src=https://sta.codeforces.com/s/62449/favicon-32x32.png width="25" height="25" />
  &nbsp;
</a>

<a target="_blank" href=https://twitter.com/tarikmanoar>
  <img height="25" width="25" src="https://abs.twimg.com/favicons/twitter.ico" />
  &nbsp;
</a>

<a target="_blank" href=mailto:tarikmanoar@gmail.com>
  <img height="25" width="25" src="https://ssl.gstatic.com/ui/v1/icons/mail/images/favicon5.ico" />
  &nbsp;
</a>
</p>

<hr>
<h3 align="center">Show me your cards </h3>
<br>

<p align="center">
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg alt=python width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg alt=html5 width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg alt=css3 width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg alt=javascript width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/sass/sass-original.svg alt=sass width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg alt=react width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg alt=nodejs width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg alt=mongodb width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/express/express-original.svg alt=express width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg alt=express width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-original.svg alt=express width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg alt=git width="30" height="30"/>
<img src=https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg alt=linux width="30" height="30"/>
</p>

<br><br>

<p align="center">

<img width="500" src="https://metrics.lecoq.io/tarikmanoar" alt="Github Metrics">
  
<br>

</p>

<br>

|![](https://github-readme-stats.vercel.app/api?username=tarikmanoar&&show_icons=true&title_color=ffffff&icon_color=bb2acf&text_color=daf7dc&bg_color=151515)|![](https://github-readme-stats.vercel.app/api/top-langs/?username=tarikmanoar&layout=compact&theme=tokyonight&langs_count=10)|
|-|-|

![](https://activity-graph.herokuapp.com/graph?username=tarikmanoar&theme=redical)

<br>

![visitors](https://visitor-badge.laobi.icu/badge?page_id=tarikmanoar.tarikmanoar)

<br>

<p align="center">
    Aww, You made this far. Here is a Gift for you.........
</p>

<br>
